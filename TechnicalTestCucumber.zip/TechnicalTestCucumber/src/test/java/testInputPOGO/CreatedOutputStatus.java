package testInputPOGO;

public class CreatedOutputStatus {

	private String created;

	public void setCreated(String created) {
		this.created = created;
	}

	public String getCreated() {
		return this.created;
	}
}
