package testInputPOGO;

public class LoginInfo {

	private String userName;

	private String password;

	private String fisrtNameModifyTo;

	private String lastNameModifyTo;

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getPassword() {
		return this.password;
	}

	public void setFisrtNameModifyTo(String fisrtNameModifyTo) {
		this.fisrtNameModifyTo = fisrtNameModifyTo;
	}

	public String getFisrtNameModifyTo() {
		return this.fisrtNameModifyTo;
	}

	public void setLastNameModifyTo(String lastNameModifyTo) {
		this.lastNameModifyTo = lastNameModifyTo;
	}

	public String getLastNameModifyTo() {
		return this.lastNameModifyTo;
	}
}
